package com.example.demo;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1")
public class MarketController {
	@Autowired
	private MarketRespository MarketRespository;

	@GetMapping("/ Market")
	public List<MarketHistory> getAllMarket() {
		return MarketRespository.findAll();

	}

	@GetMapping("/Market/{Id}")
	public ResponseEntity<MarketHistory> getMarketHistoryById(@PathVariable(value = "Id") Long MarketId)
			throws ResourceNotFoundException {
		MarketHistory Market = MarketRespository.findById(MarketId)
				.orElseThrow(() -> new ResourceNotFoundException("MarketProduct not found for this id :: " + MarketId));
		return ResponseEntity.ok().body(Market);
	}

	@PostMapping("/Market")
	public MarketHistory createEmployee(@Valid @RequestBody MarketHistory Market) {
		return MarketRespository.save(Market);
	}

	@PutMapping("/Market/{Id}")
	public ResponseEntity<MarketHistory> updateMarketHistory(@PathVariable(value = "Id") Long MarketId,
			@Valid @RequestBody MarketHistory MarketDetails) throws ResourceNotFoundException {
		MarketHistory Market = MarketRespository.findById(MarketId).orElseThrow(
				() -> new ResourceNotFoundException("MarketProduct  not found for this id :: " + MarketId));

		Market.setCustomerNo(MarketDetails.getCustomerNo());
		Market.setProductPrice(MarketDetails.getProductPrice());
		Market.setproductName(MarketDetails.getproductName());
		final MarketHistory updatedMarketHistory = MarketRespository.save(Market);
		return ResponseEntity.ok(updatedMarketHistory);
	}

	@DeleteMapping("/Market/{Id}")
	public Map<String, Boolean> deleteMarketHistory(@PathVariable(value = "Id") Long MarketId)
			throws ResourceNotFoundException {
		MarketHistory Market = MarketRespository.findById(MarketId)
				.orElseThrow(() -> new ResourceNotFoundException("MarketProduct not found for this id :: " + MarketId));

		MarketRespository.delete(Market);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return response;
	}

}
