package com.example.demo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Market5")
public class MarketHistory {
	private long Id;

	private String productName;
	private int ProductPrice;
	private int CustomerNo;

	public MarketHistory() {

	}

	public MarketHistory(long Id, String productName, int ProductPrice, int CustomerNo) {
		this.Id = Id;
		this.productName = productName;
		this.ProductPrice = ProductPrice;
		this.CustomerNo = CustomerNo;

	}

	@Id

	public long getproductId() {
		return Id;
	}

	public void setproductId(long Id) {
		this.Id = Id;
	}

	@Column(name = "productName", nullable = false)
	public String getproductName() {
		return productName;
	}

	public void setproductName(String productName) {
		this.productName = productName;
	}

	@Column(name = "ProductPrice", nullable = false)
	public int getProductPrice() {
		return ProductPrice;
	}

	public void setProductPrice(int ProductPrice) {
		this.ProductPrice = ProductPrice;
	}

	@Column(name = "CustomerNo", nullable = false)
	public int getCustomerNo() {
		return CustomerNo;
	}

	public void setCustomerNo(int customerNo) {
		CustomerNo = customerNo;
	}

}
